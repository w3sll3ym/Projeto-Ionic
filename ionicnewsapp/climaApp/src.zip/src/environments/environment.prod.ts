export const environment = {
  production: true,
  openWeatherApiKey: '137e120903116dc8411861ce9f3a0af4',
  firebaseConfig: {
    apiKey: "AIzaSyB6alfj5LwpqqWN9vW7sUWTWizcjFTw-kI",
    authDomain: "climaappfirebase.firebaseapp.com",
    projectId: "climaappfirebase",
    storageBucket: "climaappfirebase.appspot.com",
    messagingSenderId: "406976441772",
    appId: "1:406976441772:web:1a986fdc12297df4c5de09"
  }
};
